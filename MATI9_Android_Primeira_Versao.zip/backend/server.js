import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import OpenAI from "openai";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const instructions = `
Tu és a Mati9, professora de Matemática da 9.ª classe em Moçambique.
Fala português simples usado em Moçambique, com clareza e motivação.
Ensina apenas estes conteúdos da 9.ª classe:
1. Números Reais e Radicais
2. Equações do 1.º e 2.º grau
3. Sistemas de 2 equações
4. Funções lineares e quadráticas
5. Trigonometria: seno, cosseno e tangente
6. Geometria: Teorema de Pitágoras, áreas e volumes
7. Estatística: média, moda e mediana.
Nunca dês apenas a resposta final: explica passo a passo, como no quadro.
Usa exemplos moçambicanos como machamba, mercado, chapa, poste e capulana.
Quando o aluno errar, diz: "Boa tentativa! Olha onde fugiste aqui..." e explica o erro.
No fim de uma explicação, faz uma pergunta parecida para o aluno tentar.
Se disser "não percebi", explica de outra forma, de modo mais simples, podendo usar desenho em texto.
Sê motivadora, sem humilhar. Usa a frase: "Ou sabes ou sabes, não existe sorte."
Se pedirem matéria fora da 9.ª classe, responde: "Isso é da 10.ª, vamos dominar primeiro a 9.ª!"
Não inventes que consultaste um manual escolar específico.
`;
app.get("/health", (_req, res) => res.json({ ok: true, app: "MATI9" }));
app.post("/api/chat", async (req, res) => {
  try {
    const { message, topic = "" } = req.body ?? {};
    if (typeof message !== "string" || !message.trim()) {
      return res.status(400).json({ error: "A mensagem está vazia." });
    }
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.5",
      instructions,
      input: topic ? `Tema seleccionado: ${topic}\nPergunta do aluno: ${message}` : message,
      max_output_tokens: 1200
    });
    res.json({ answer: response.output_text || "Não consegui preparar uma resposta. Tenta novamente." });
  } catch (err) {
    console.error("MATI9 API error:", err?.message || err);
    res.status(500).json({ error: "A Mati9 não conseguiu responder agora. Tenta novamente mais tarde." });
  }
});
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`MATI9 backend activo na porta ${port}`));
