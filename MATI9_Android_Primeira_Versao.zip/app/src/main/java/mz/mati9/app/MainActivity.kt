package mz.mati9.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Navy = Color(0xFF123B70)
private val Yellow = Color(0xFFFFC928)
private val Pale = Color(0xFFF3F7FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Mati9App() }
    }
}

@Composable
fun Mati9App() {
    var tab by remember { mutableStateOf("Início") }
    var selectedTopic by remember { mutableStateOf<String?>(null) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Yellow, background = Pale)) {
        Scaffold(
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Início", "Matérias", "Professora IA", "Testes").forEach {
                        NavigationBarItem(
                            selected = tab == it,
                            onClick = { tab = it; selectedTopic = null },
                            icon = { Text(when(it) { "Início" -> "⌂"; "Matérias" -> "▤"; "Professora IA" -> "✦"; else -> "✓" }, fontSize = 20.sp) },
                            label = { Text(it, fontSize = 10.sp) }
                        )
                    }
                }
            },
            containerColor = Pale
        ) { padding ->
            when (tab) {
                "Início" -> HomeScreen(Modifier.padding(padding)) { tab = "Professora IA" }
                "Matérias" -> TopicsScreen(Modifier.padding(padding), selectedTopic) { selectedTopic = it; tab = "Professora IA" }
                "Professora IA" -> ChatScreen(Modifier.padding(padding), selectedTopic)
                else -> QuizScreen(Modifier.padding(padding)) { tab = "Professora IA"; selectedTopic = it }
            }
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier = Modifier, start: () -> Unit) {
    Column(modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.SpaceBetween) {
        Column {
            Text("MATI9", color = Navy, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold)
            Text("A tua professora de Matemática da 9.ª classe", color = Navy, fontSize = 16.sp)
            Spacer(Modifier.height(28.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(22.dp)) {
                    Text("Aprender Matemática\nnunca foi tão fácil!", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Text("Explicações passo a passo, exercícios e preparação para testes.", color = Color.White)
                    Spacer(Modifier.height(20.dp))
                    Button(onClick = start, colors = ButtonDefaults.buttonColors(containerColor = Yellow)) {
                        Text("COMEÇAR", color = Navy, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
            Text("O que podes aprender", color = Navy, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            listOf("Números reais e radicais", "Equações e sistemas", "Funções", "Trigonometria", "Geometria", "Estatística").forEach {
                Text("•  $it", modifier = Modifier.padding(top = 10.dp), color = Color.DarkGray)
            }
        }
        Text("Desenvolvido por Ismael Guilherme Baltazar", color = Navy, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

val topics = listOf(
    "Números Reais e Radicais",
    "Equações do 1.º e 2.º grau",
    "Sistemas de 2 equações",
    "Funções lineares e quadráticas",
    "Trigonometria: sen, cos e tan",
    "Geometria: Pitágoras, áreas e volumes",
    "Estatística: média, moda e mediana"
)

@Composable
fun TopicsScreen(modifier: Modifier = Modifier, selected: String?, onChoose: (String) -> Unit) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("Matérias da 9.ª classe", fontSize = 26.sp, color = Navy, fontWeight = FontWeight.Bold)
        Text("Escolhe um tema para estudar.", color = Color.Gray)
        Spacer(Modifier.height(14.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(topics) { topic ->
                Card(Modifier.fillMaxWidth().clickable { onChoose(topic) }, colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("📘", fontSize = 22.sp)
                        Spacer(Modifier.width(12.dp))
                        Text(topic, color = Navy, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

data class ChatLine(val text: String, val fromUser: Boolean)

@Composable
fun ChatScreen(modifier: Modifier = Modifier, topic: String?) {
    val messages = remember(topic) {
        mutableStateListOf(ChatLine(
            if (topic == null) "Olá! Sou a Mati9. Qual exercício ou matéria da 9.ª classe vamos aprender hoje?" else
                "Vamos estudar: $topic. Envia uma dúvida ou pede um exercício. Vou explicar passo a passo!",
            false
        ))
    }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Column(modifier.fillMaxSize().padding(14.dp)) {
        Text("Professora IA", fontSize = 26.sp, color = Navy, fontWeight = FontWeight.Bold)
        Text("Mati9 • Matemática da 9.ª classe", color = Color.Gray)
        Spacer(Modifier.height(10.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(messages) { line ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.fromUser) Arrangement.End else Arrangement.Start) {
                    Surface(color = if (line.fromUser) Navy else Color.White, shape = RoundedCornerShape(16.dp)) {
                        Text(line.text, Modifier.widthIn(max = 300.dp).padding(14.dp), color = if (line.fromUser) Color.White else Color.DarkGray)
                    }
                }
            }
            if (loading) item { Text("A Mati9 está a preparar a explicação…", color = Navy) }
            error?.let { item { Text(it, color = Color.Red) } }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f).background(Color.White, RoundedCornerShape(20.dp)).padding(14.dp), decorationBox = { inner ->
                if (input.isEmpty()) Text("Escreve a tua dúvida…", color = Color.Gray)
                inner()
            })
            Spacer(Modifier.width(8.dp))
            Button(enabled = input.isNotBlank() && !loading, onClick = {
                val question = input.trim()
                input = ""
                messages.add(ChatLine(question, true))
                loading = true; error = null
                scope.launch {
                    val answer = askMati9(question, topic)
                    if (answer.startsWith("ERRO:")) error = answer.removePrefix("ERRO:")
                    else messages.add(ChatLine(answer, false))
                    loading = false
                }
            }) { Text("Enviar") }
        }
    }
}

suspend fun askMati9(question: String, topic: String?): String = withContext(Dispatchers.IO) {
    try {
        // Configure this URL with the public HTTPS address of your own backend.
        val endpoint = BuildConfigPlaceholder.API_BASE_URL.trimEnd('/') + "/api/chat"
        val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
        }
        val body = JSONObject().put("message", question).put("topic", topic ?: "").toString()
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val responseCode = conn.responseCode
        val stream = if (responseCode in 200..299) conn.inputStream else conn.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        conn.disconnect()
        if (responseCode !in 200..299) "ERRO: O servidor respondeu com erro ($responseCode). Verifica a configuração." 
        else JSONObject(response).optString("answer", "Não consegui obter uma resposta.")
    } catch (e: Exception) {
        "ERRO: Não foi possível ligar à MATI9. Confirma a Internet e o endereço do servidor."
    }
}

// Substitui o endereço no ficheiro local.properties ou directamente nesta constante antes de compilar.
private object BuildConfigPlaceholder {
    const val API_BASE_URL = "https://COLOCA-AQUI-O-ENDERECO-DO-TEU-SERVIDOR"
}

@Composable
fun QuizScreen(modifier: Modifier = Modifier, openTopic: (String) -> Unit) {
    var answer by remember { mutableStateOf<Int?>(null) }
    Column(modifier.fillMaxSize().padding(22.dp)) {
        Text("Mini-teste", color = Navy, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Text("Quanto é 3² + 4²?", fontSize = 20.sp, color = Color.DarkGray, fontWeight = FontWeight.SemiBold)
        listOf( "A  7", "B  12", "C  25", "D  49").forEachIndexed { index, label ->
            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { answer = index }, colors = CardDefaults.cardColors(containerColor = if (answer == index) Yellow else Color.White)) {
                Text(label, Modifier.padding(16.dp), color = Navy)
            }
        }
        answer?.let {
            Spacer(Modifier.height(12.dp))
            Text(if (it == 2) "Boa! 3² + 4² = 9 + 16 = 25." else "Boa tentativa! A resposta é 25, porque 9 + 16 = 25.", color = Navy)
            Text("Queres praticar mais? Abre a Professora IA.", Modifier.clickable { openTopic("Números Reais e Radicais") }.padding(top = 16.dp), color = Navy)
        }
        Spacer(Modifier.height(16.dp))
        Text("Ou sabes ou sabes, não existe sorte.", color = Navy, fontWeight = FontWeight.Bold)
    }
}
