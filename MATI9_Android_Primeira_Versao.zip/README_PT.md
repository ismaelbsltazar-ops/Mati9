# MATI9 — projecto Android inicial

Este pacote contém uma primeira versão funcional da interface Android e o servidor que liga a aplicação à IA.

## O que já está incluído
- Ecrã inicial com o texto exacto: **Desenvolvido por Ismael Guilherme Baltazar**
- Separadores Início, Matérias, Professora IA e Testes
- Os sete conteúdos definidos para a 9.ª classe
- Chat ligado a um servidor de IA (quando o servidor estiver configurado e publicado)
- Instruções pedagógicas da Mati9 no servidor
- Um mini-teste inicial de demonstração

## Importante: ainda não é um APK instalado
É um projecto-fonte Android Studio. Precisa de ser compilado e testado num computador com Android Studio. O chat só funcionará depois de configurar e publicar o servidor HTTPS.

## 1. Configurar o servidor da IA
1. Instala Node.js num computador.
2. Abre a pasta `backend`.
3. Copia `.env.example` para `.env`.
4. Preenche `OPENAI_API_KEY` com uma chave API guardada em segurança.
5. Executa `npm install` e depois `npm start`.
6. Publica o servidor num serviço que forneça um endereço HTTPS.
7. Nunca coloques a chave API dentro da aplicação Android nem a partilhes publicamente. Como és menor, pede a um adulto responsável para ajudar a configurar a conta e controlar eventuais custos.

A ligação usa a OpenAI Responses API. Documentação oficial:
https://developers.openai.com/api/reference/resources/responses/methods/create

## 2. Ligar a aplicação ao servidor
No ficheiro:
`app/src/main/java/mz/mati9/app/MainActivity.kt`

Substitui:
`https://COLOCA-AQUI-O-ENDERECO-DO-TEU-SERVIDOR`

pelo endereço HTTPS do servidor publicado, sem a barra final.

## 3. Abrir e compilar
1. Abre Android Studio.
2. Escolhe **Open** e selecciona a pasta `MATI9_Android`.
3. Aguarda a sincronização do Gradle.
4. Liga um telemóvel Android com depuração USB activada ou usa um emulador.
5. Carrega em **Run** para testar.

## 4. O que falta para uma versão de lançamento
- Testar em vários telemóveis e corrigir erros.
- Adicionar envio de fotografias de fichas (ainda não implementado).
- Criar histórico de conversas e progresso guardado.
- Melhorar o sistema de testes e correcção.
- Configurar privacidade, segurança, limites de utilização e monitorização do servidor.
- Preparar ícone, política de privacidade e publicação.

Esta é uma primeira versão para avaliação, não uma aplicação final pronta para a Play Store.


## Pré-visualização rápida
Abre o ficheiro `preview.html` num navegador para veres e experimentares o desenho básico da MATI9. A pré-visualização demonstra os ecrãs e o mini-teste; a conversa com IA ainda é ilustrativa até o servidor estar publicado e ligado.
